export const TINY_API_URL = 'https://api.tiny.com.br/api2';
export const TINY_API_TOKEN = process.env.TINY_API_TOKEN;

export const WHATSAPP_API_URL = 'https://sua-api-whatsapp.com';
export const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
